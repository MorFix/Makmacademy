﻿using Server.Models;

namespace Server.ViewModels
{
    public class UserViewModel
    {
        public UserViewModel(User user)
        {
            // TODO: what should we do here
        }
    }
}